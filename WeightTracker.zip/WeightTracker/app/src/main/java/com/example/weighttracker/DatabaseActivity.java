package com.example.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** @noinspection ALL*/
public class DatabaseActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    private TextInputEditText dateInput, weightInput;
    private TextInputLayout dateInputLayout, weightInputLayout;
    private RecyclerView weightRecyclerView;
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;

    private int selectedId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        dbHelper = new DatabaseHelper(this);

        // Find inputs
        dateInputLayout = findViewById(R.id.dateInputLayout);
        weightInputLayout = findViewById(R.id.weightInputLayout);
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);

        Button addButton = findViewById(R.id.addButton);
        Button updateButton = findViewById(R.id.updateButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        weightRecyclerView = findViewById(R.id.weightRecyclerView);
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadWeightList();

        adapter.setOnItemClickListener(entry -> {
            selectedId = entry.getId();
            dateInput.setText(entry.getDate());
            weightInput.setText(String.valueOf(entry.getWeight()));
        });

        addButton.setOnClickListener(v -> {
            String date = Objects.requireNonNull(dateInput.getText()).toString().trim();
            String weightStr = Objects.requireNonNull(weightInput.getText()).toString().trim();

            if (validateInputs(date, weightStr)) return;

            double weight = Double.parseDouble(weightStr);
            boolean inserted = dbHelper.insertWeight(date, weight);
            if (inserted) {
                sendSMSAlert("New weight entry added: " + weight + " lbs on " + date);
                Toast.makeText(this, "Weight entry added", Toast.LENGTH_SHORT).show();
                clearInputs();
                loadWeightList();
            } else {
                Toast.makeText(this, "Failed to add entry", Toast.LENGTH_SHORT).show();
            }
        });

        updateButton.setOnClickListener(v -> {
            if (selectedId == -1) {
                Toast.makeText(this, "Select an entry to update", Toast.LENGTH_SHORT).show();
                return;
            }

            String date = Objects.requireNonNull(dateInput.getText()).toString().trim();
            String weightStr = Objects.requireNonNull(weightInput.getText()).toString().trim();

            if (validateInputs(date, weightStr)) return;

            double weight = Double.parseDouble(weightStr);
            boolean updated = dbHelper.updateWeight(selectedId, date, weight);
            if (updated) {
                Toast.makeText(this, "Entry updated", Toast.LENGTH_SHORT).show();
                selectedId = -1;
                clearInputs();
                loadWeightList();
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });

        deleteButton.setOnClickListener(v -> {
            if (selectedId == -1) {
                Toast.makeText(this, "Select an entry to delete", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean deleted = dbHelper.deleteWeight(selectedId);
            if (deleted) {
                Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
                selectedId = -1;
                clearInputs();
                loadWeightList();
            } else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });

        checkSmsPermission();
    }

    private boolean validateInputs(String date, String weightStr) {
        boolean valid = true;

        if (date.isEmpty()) {
            dateInputLayout.setError("Date is required");
            valid = false;
        } else {
            dateInputLayout.setError(null);
        }

        if (weightStr.isEmpty()) {
            weightInputLayout.setError("Weight is required");
            valid = false;
        } else {
            weightInputLayout.setError(null);
        }

        return !valid;
    }

    private void clearInputs() {
        dateInput.setText("");
        weightInput.setText("");
        dateInputLayout.setError(null);
        weightInputLayout.setError(null);
    }

    private void loadWeightList() {
        List<WeightEntry> weights = dbHelper.getAllWeightEntries();
        adapter = new WeightAdapter(new ArrayList<>(weights));
        weightRecyclerView.setAdapter(adapter);
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    private void sendSMSAlert(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("+19998887777", null, message, null, null); // Emulator number
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }
}

