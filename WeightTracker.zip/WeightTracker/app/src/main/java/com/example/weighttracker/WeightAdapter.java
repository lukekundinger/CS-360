package com.example.weighttracker;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final List<WeightEntry> weightList;
    private OnItemClickListener listener;

    public WeightAdapter(List<WeightEntry> weightList) {
        this.weightList = weightList;
    }

    public interface OnItemClickListener {
        void onItemClick(WeightEntry entry);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new WeightViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.dateView.setText("Date: " + entry.getDate());
        holder.weightView.setText("Weight: " + entry.getWeight() + " lbs");
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView dateView;
        TextView weightView;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            dateView = itemView.findViewById(android.R.id.text1);
            weightView = itemView.findViewById(android.R.id.text2);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(weightList.get(position));
                }
            });
        }
    }
}


